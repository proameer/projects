<script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>
<link href="<?php echo e(asset('assetsuser/css/webticker.css')); ?>" rel="stylesheet" type="text/css" media="screen">
<script type="text/javascript" src="<?php echo e(asset('assetsuser/js/jquery.webticker.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#webticker").webTicker();
	// $("#webticker2").webTicker({duplicate:true, speed: 40, direction: 'right', rssurl:'http://yourwebsite.com/rss/', rssfrequency:1, startEmpty:false, hoverpause:false});	
	
	$("#stop").click(function(){
		$("#webticker").webTicker('stop');
	});
	
	$("#continue").click(function(){
		$("#webticker").webTicker('cont');
	});
});
</script>

<header id="header">
  <div class="container">
    <nav class="navbar navbar-expand-lg navbar-light">
    
      <div class="navbar-bottom pt-4">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <img
            src="../image/<?php echo e(about()[0]->image); ?>"
            alt="banner"
            class="img-fluid ml-2" width="50px"
          />
            <a class="navbar-brand text-white" href="<?php echo e(url('/')); ?>">   <?php echo e(about()[0]->name); ?></a>
          </div>
          <div>
            <button
              class="navbar-toggler"
              type="button"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon "></span>
            </button>
            <div
              class="navbar-collapse justify-content-center collapse"
              id="navbarSupportedContent"
            >
            
              <ul class="navbar-nav d-lg-flex justify-content-between align-items-center">
                <li>
                  <button class="navbar-close">
                    <i class="mdi mdi-close"></i>
                  </button>
                </li>
                <li class="nav-item active">
                  <a class="nav-link" href="<?php echo e(url('/')); ?>">الرئيسية </a>
                </li>
               
               <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  التصنيفات
                </a>               
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <?php $__currentLoopData = category(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                 
                    <a class="dropdown-item" href="<?php echo e(url('category' , $item->id)); ?>"><?php echo e($item->nameCategory); ?></a>                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </div>
               </li>
               <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('contactus')); ?>">تواصل معنا</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('aboutus')); ?>"> حول</a>
              </li>
              </ul>
            </div>
          </div>
          
          <ul class="navbar-nav" >
            
          </ul>
       
        </div>
      </div>
    </nav>
  </div>
</header>
<?php /**PATH C:\xampp\htdocs\blogNews\resources\views/navbar.blade.php ENDPATH**/ ?>