
<?php $__env->startSection('title'); ?>
    الصلاحيات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  الصلاحيات
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  تعديل
              <?php $__env->stopSection(); ?>
                    <!-- /# column -->
                    <div class="col-lg-12">
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>خطأ!</strong>حدث <br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <div class="card">
                            <div class="card-title">
                                <h4>تعديل صلاحية</h4>
                                <a class="btn btn-primary float-right" href="<?php echo e(route('permissions.index')); ?>">رجوع</a>

                            </div>
            
          
                            <div class="card-body">
                                <div class="basic-form">
                                
                                      
                                    <?php echo Form::model($permission, ['route' => ['permissions.update', $permission->id], 'method'=>'PATCH']); ?>

                                    <div class="form-group">
                                        <strong>اسم الصلاحية:</strong>
                                        <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

                                    </div>
                                    <button type="submit" class="btn btn-primary">تحديث</button>
                                <?php echo Form::close(); ?>

                                    
                                       
                             
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /# row -->
               
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/permissions/edit.blade.php ENDPATH**/ ?>