<style>
  input::placeholder , textarea::placeholder{
    color: tomato !important;
  }
form {
    background: #ecf5fc;
    padding: 40px 50px 45px;
}
.form-control:focus {
    border-color: #000;
    box-shadow: none;
}
label {
    font-weight: 600;
}
.error {
    color: red;
    font-weight: 400;
    display: block;
    padding: 6px 0;
    font-size: 14px;
    text-align: right;
}
.form-control.error {
    border-color: red;
    padding: .375rem .75rem;
}
</style>
<?php $__env->startSection('content'); ?>

<!-- Small modal -->

<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content text-center">
      <br><br><br>
     <h1> تم الارسال بنجاح</h1>
      <br><br><br>
    </div>
  </div>
</div>

      <div class="content-wrapper">
        <div class="container">
          <div class="row">
            <div class="col-sm-12">
              <div class="card" data-aos="fade-up">
                <div class="card-body">
                  <div class="aboutus-wrapper">
                    <h1 class="mt-5 text-center mb-5">
                      اتصل بنا
                    </h1>
                    <div class="row">
                      <div class="col-lg-12 mb-5 mb-sm-2">
                      
                        <form method="POST" action="<?php echo e(route('contact')); ?>">
                          <?php echo csrf_field(); ?>
                          <?php echo e(method_field('post')); ?>

                          
                          <div class="row">
                            <div class="col-sm-6">
                              <div class="form-group">
                                <input
                                  type="text"
                                  class="form-control <?php echo e($errors->has('name') ? 'error' : ''); ?>"
                                  name="name"
                                  aria-describedby="name"
                                  placeholder="الاسم الكامل *"
                                  value="<?php echo e(old('name')); ?>"
                                />
                                <!-- Error -->
                                <?php if($errors->has('name')): ?>
                                <div class="error">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                                <?php endif; ?>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="form-group">
                                <input
                                  type="email"
                                  class="form-control <?php echo e($errors->has('email') ? 'error' : ''); ?>"
                                  name="email"
                                  aria-describedby="email"
                                  placeholder="البريد الالكتروني *"
                                  value="<?php echo e(old('email')); ?>"
                                />
                                  <!-- Error -->
                                  <?php if($errors->has('email')): ?>
                                  <div class="error">
                                      <?php echo e($errors->first('email')); ?>

                                  </div>
                                  <?php endif; ?>
                              </div>
                            </div>
                          </div>
                          
                          <div class="row">
                            <div class="col-sm-12 ">
                              <div class="form-group">
                                <input
                                  type="text"
                                  class="form-control <?php echo e($errors->has('subject') ? 'error' : ''); ?>"
                                  name="subject"
                                  aria-describedby="subject"
                                  placeholder="الموضوع *"
                                  value="<?php echo e(old('subject')); ?>"
                                />
                                  <!-- Error -->
                                  <?php if($errors->has('subject')): ?>
                                  <div class="error">
                                      <?php echo e($errors->first('subject')); ?>

                                  </div>
                                  <?php endif; ?>
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-sm-12">
                              <div class="form-group">
                                <textarea
                                class="form-control <?php echo e($errors->has('message') ? 'error' : ''); ?>"
                                  placeholder="الرسالة *"
                                  name="message"
                                  value="<?php echo e(old('message')); ?>"
                                ></textarea>
                                <!-- Error -->
                                <?php if($errors->has('message')): ?>
                                <div class="error">
                                    <?php echo e($errors->first('message')); ?>

                                </div>
                                <?php endif; ?>
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-sm-12">
                              <div class="form-group">
                                
                                <button type="submit" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-sm">ارسال</button>
                              </div>
                            </div>
                          </div>

                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/contactus.blade.php ENDPATH**/ ?>