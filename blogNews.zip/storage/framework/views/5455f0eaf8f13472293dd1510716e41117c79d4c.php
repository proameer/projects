
<?php $__env->startSection('title'); ?>
    حول 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  حول 
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  عرض
              <?php $__env->stopSection(); ?>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                       
                        <!-- /# column -->
                        <div class="col-lg-12">  
                            
                           

                            <div class="card">
                                
                                <div class="card-title">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post-list')): ?>
                                    <a class="btn btn-primary float-right" href="<?php echo e(route('about.index')); ?>">رجوع</a>                      
                            <?php endif; ?>
                                    <h4>عرض </h4>
 
                                </div>
                                <div class="card-body">
                                   <div class="row">
                                    <div class="col-md-5">
                                        <div class="lead">
                                             <img src="/image/<?php echo e($about->image); ?>" class="w-100"> 
                                        </div>
                                       </div>
                                       <div class="col-md-7">
                                        <div class="lead">
                                            <strong>اسم الموقع</strong><br>
                                            <?php echo e($about->name); ?>

                                        </div><hr>
                                        <div class="lead">
                                            <strong>الوصف</strong><br>
                                            <?php echo e($about->description); ?>

                                        </div><hr>
                                       
                                       </div>
                                      
                                   </div>
                                
                    
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                   
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/about/show.blade.php ENDPATH**/ ?>