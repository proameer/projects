
<?php $__env->startSection('title'); ?>
    المنشورات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  المنشورات
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  تعديل
              <?php $__env->stopSection(); ?>
                    <!-- /# column -->
                    <div class="col-lg-12">
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>خطأ!</strong>حدث <br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <div class="card">
                            <div class="card-title">
                                <h4>تعديل منشور</h4>
                                <a class="btn btn-primary float-right" href="<?php echo e(route('posts.index')); ?>">رجوع</a>

                            </div>
            
          
                            <div class="card-body">
                                <div class="basic-form">
                                
                                      
                                    <?php echo Form::model($post, ['route' => ['posts.update', $post->id], 'method'=>'PATCH', 'enctype'=>'multipart/form-data']); ?>

                                    <div class="form-group">
                                        <strong>العنوان:</strong>
                                        <?php echo Form::text('title', null, array('placeholder' => 'Title','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>الوصف:</strong>
                                        <textarea name="description" , id="summernote" , class="form-control" , cols="30" rows="10"><?php echo e($post->description); ?></textarea>
                                        
                                    </div>
                                    <div class="form-group">
                                        <strong>الصورة:</strong>
                                        <input type="file" name="image"  value="image/<?php echo e(old($post->image)); ?>" class="form-control">
                                        <img src="/image/<?php echo e($post->image); ?>" alt="" width="100px">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect2" for="category_id" class="form-label"> التصنيف</label>
                                        <select class="form-control" name="category_id">
                                          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($item->id); ?>" class="form-control" id="category_id"name="category_id" ><?php echo e($item->nameCategory); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>                        
                                      </div>
                                    <button type="submit" class="btn btn-primary">تحديث</button>
                                <?php echo Form::close(); ?>

                                       
                             
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /# row -->
            
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/posts/edit.blade.php ENDPATH**/ ?>