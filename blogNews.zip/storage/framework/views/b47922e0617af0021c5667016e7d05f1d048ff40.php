
<?php $__env->startSection('title'); ?>
    الصلاحيات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  الصلاحيات
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  الرئيسية
              <?php $__env->stopSection(); ?>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                       
                        <!-- /# column -->
                        <div class="col-lg-12">  
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-create')): ?>                                     
                             <a class="btn btn-success" href="<?php echo e(route('permissions.create')); ?>">صلاحية جديده</a>
                            <?php endif; ?>

                            <div class="card">
                                
                                <div class="card-title">
                                    
                                    <h4>الصلاحيات </h4>
 
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover ">
                                            <thead>
                                                <tr>
                                                    <th>اسم الصلاحية</th>
                                                    <th>الحدث</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($permission->name); ?></td>
                                                    <td>
                                                        <a class="btn btn-info" href="<?php echo e(route('permissions.show',$permission->id)); ?>">عرض</a>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-edit')): ?>
                                                            <a class="btn btn-primary" href="<?php echo e(route('permissions.edit',$permission->id)); ?>">تعديل</a>
                                                        <?php endif; ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-delete')): ?>
                                                            <?php echo Form::open(['method' => 'DELETE','route' => ['permissions.destroy', $permission->id],'style'=>'display:inline']); ?>

                                                            <?php echo Form::submit('حذف', ['class' => 'btn btn-danger']); ?>

                                                            <?php echo Form::close(); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php echo e($data->appends($_GET)->links()); ?>

                                        
                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                  
                </section>
            </div>
        </div>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/permissions/index.blade.php ENDPATH**/ ?>