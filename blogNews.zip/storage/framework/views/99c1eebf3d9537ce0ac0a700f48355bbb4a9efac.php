<?php $__env->startSection('content'); ?>

        <div class="content-wrapper" dir="ltr">
          <div class="container">
            <div class="col-sm-12">
              <div class="card" data-aos="fade-up">
                <div class="card-body">
                  <div class="row">

                   

                    <div class="col-lg-8 text-right">
                  

                        <div id="myCarousel" class="carousel slide" data-ride="carousel">

                          <div class="carousel-inner">
                              <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                  <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                                    <img src="<?php echo e(url('image', $item->image)); ?>" class="d-block w-100"  alt="..." style="filter: brightness(30%);"> 
                                    <div class="carousel-caption">
                                      <a href="<?php echo e(url('singleCategory' , $item->id)); ?>">
                                      <h3 class=" p-3 text-light"><?php echo e($item->title); ?></h3>
                                    </a>
                                    </div>
                                  </div>
                             
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                          <a class="carousel-control-prev" href="#myCarousel" role="button"  data-slide="prev">
                              <span class="carousel-control-prev-icon" aria-hidden="true">     </span>
                              <span class="sr-only">Previous</span>
                          </a>
                          <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                              <span class="carousel-control-next-icon" aria-hidden="true"></span>
                              <span class="sr-only">Next</span>
                          </a>
                      </div>
                      
                        
                     

                      
                    
                      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                      <hr>            
                      <div class="row text-right" dir="rtl">
                        <div class="col-sm-4">
                          <div class="rotate-img">
                            <img
                            src="../image/<?php echo e($item->image); ?>"
                            alt="banner"
                            class="img-fluid" width="180px"
                          />
                        
                          </div>
                        </div>
                        <div class="col-sm-8">
                         <a href="<?php echo e(url('singleCategory' , $item->id)); ?>">
                            <h2 class="font-weight-600 mb-2">
                                <?php echo e($item->title); ?>

                              </h2>
                         </a>
                          <p class="fs-13 text-muted mb-0">
                            <span class="mr-2">تم النشر </span><?php echo e($item->created_at->diffForHumans()); ?>

                          </p>
                          <span class="badge badge-danger"> <?php echo e($item->category->nameCategory); ?></span>
                          
                        </div>
                      </div>
                    
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <div>
                       
                      
                      </div>
                      <div>

                      </div>
                
                
                    </div>
                 
            

                    <div class="col-lg-4 text-right bg-light">
                      <h2 class="mt-2 text-primary font-weight-600">
                        التصنيفات
                      </h2>

                      
                 
                      <div class="row">
                        <div class="col-sm-12">
                          <div class="border-bottom pb-4 pt-4">
                            <div class="row">
                              <div class="col-sm-12">
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('category' , $item->id)); ?>">
                                  <h1 class="m-1 p-2 w-5 badge badge-danger"><?php echo e($item->nameCategory); ?></h1>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     

                           
                              </div>
                             
                            </div>
                          </div>
                        </div>
                      </div>
                      
      

                      <h2 class="my-4 text-primary font-weight-600">
                        اخر الاخبار
                      </h2>
                      <?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('singleCategory' , $item->id)); ?>">
                          <div class="row">
                            <div class="col-sm-12">
                              <div class="border-bottom pb-4 pt-4">
                                <div class="row">
                                  <div class="col-sm-8">
                                    <h5 class="font-weight-600 mb-1">
                                      <?php echo e($item->title); ?>

                                    </h5>
                                    <p class="fs-13 text-muted mb-0">
                                      <span class="mr-2">تم النشر </span><?php echo e($item->created_at->diffForHumans()); ?>

                                    </p>
                                  </div>
                                  <div class="col-sm-4">
                                    <div class="rotate-img">
                                      <img
                                        src="image/<?php echo e($item->image); ?>"
                                        alt="banner"
                                        class="img-fluid" width="100px"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div> 
                        </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
                    
                    </div>
                    <div class="post-comment-section text-right" dir="rtl">
                      <h3 class="font-weight-600">اخبار عشوائية</h3>
                      <div class="row">

                        <?php $__currentLoopData = $postByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        
                        <div class="col-sm-12 col-md-6 col-lg-3">
                          <a href="<?php echo e(url('singleCategory' , $item->id)); ?>">
                          <div class="post-author">
                            <div class="rotate-img">
                              <img
                                src="image/<?php echo e($item->image); ?>"
                                alt="banner"
                                class="img-fluid"
                              />
                            </div>
                            <div class="post-author-content">
                              <h5 class="mb-1">
                                <?php echo e($item->title); ?>

                              </h5>
                              <span class="badge badge-secondary"><?php echo e($item->category->nameCategory); ?></span>

                              <p class="fs-13 text-muted mb-0">
                                <span class="mr-2">تم النشر </span><?php echo e($item->created_at->diffForHumans()); ?>

                              </p>
                            </div>
                          </div>
                          </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/index.blade.php ENDPATH**/ ?>