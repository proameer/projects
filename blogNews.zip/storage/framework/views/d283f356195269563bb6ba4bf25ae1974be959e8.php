
<?php $__env->startSection('title'); ?>
    رسائل المستخدمين 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  رسائل المستخدمين 
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  عرض
              <?php $__env->stopSection(); ?>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                       
                        <!-- /# column -->
                        <div class="col-lg-12">  
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>خطأ!</strong>حدث <br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                           

                            <div class="card">
                                
                                <div class="card-title">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post-list')): ?>
                                    <a class="btn btn-primary float-right" href="<?php echo e(route('contact.index')); ?>">رجوع</a>                      
                            <?php endif; ?>
                                    <h4>عرض رسائل المستخدمين </h4>
 
                                </div>
                                <div class="card-body">
                                   <div class="row">
                               
                                       <div class="col-md-7">
                                        <div class="lead">
                                            <strong>اسم المستخدم</strong><br>
                                            <?php echo e($contact->name); ?>

                                        </div><hr>
                                        <div class="lead">
                                            <strong>البريد الالكتروني</strong><br>
                                            <?php echo e($contact->email); ?>

                                        </div><hr>
                                        <div class="lead">
                                            <strong>الموضوع</strong><br>
                                            <?php echo e($contact->subject); ?>

                                        </div><hr>
                                        <div class="lead">
                                            <strong>الرسالة</strong><br>
                                            <?php echo e($contact->message); ?>

                                        </div><hr>
                                       
                                       </div>
                                      
                                   </div>
                                
                    
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

       
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/contact/show.blade.php ENDPATH**/ ?>