

<?php $__env->startSection('content'); ?>
    

       <div class="content-wrapper text-right" dir="ltr">
          <div class="container">
            <div class="col-sm-12">
              <div class="card" data-aos="fade-up">
                <div class="card-body">
                
                  <div class="row ">
                    <div class="col-lg-8">
                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                      <div class="row" dir="rtl">
                        <div class="col-sm-4">
                          <div class="rotate-img">
                            <img
                            src="../image/<?php echo e($item->image); ?>"
                            alt="banner"
                            class="img-fluid" width="180px"
                          />
                        
                          </div>
                        </div>
                        <div class="col-sm-8 ">
                         <a href="<?php echo e(url('singleCategory' , $item->id)); ?>">
                            <h2 class="font-weight-600 mb-2">
                                <?php echo e($item->title); ?>

                              </h2>
                         </a>
                          <p class="fs-13 text-muted mb-0">
                            <span class="mr-2">تم النشر </span><?php echo e($item->created_at->diffForHumans()); ?>

                          </p>
                          <span class="badge badge-danger"> <?php echo e($item->category->nameCategory); ?></span>
                          
                        </div>
                      </div>
                      <hr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </div>
                    
                    <div class="col-lg-4 text-right bg-light">
                      <div class="row bg-danger">
                        <div class="col-sm-12">
                          <h1 class="font-weight-600 text-light mt-2">
                            <?php echo e($category->nameCategory); ?>

                            
                          
                          
                          </h1>
                        </div>
                      </div>
                      <h2 class="mt-2 text-primary font-weight-600">
                        التصنيفات
                      </h2>
                      <div class="row">
                        <div class="col-sm-12">
                          <div class="border-bottom pb-4 pt-4">
                            <div class="row">
                              <div class="col-sm-12">
                                <?php $__currentLoopData = $categoryname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('category' , $item->id)); ?>">
                                  <h1 class="m-1 p-2 w-5 badge badge-danger"><?php echo e($item->nameCategory); ?></h1>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                               
                        
                              </div>
                             
                            </div>
                          </div>
                        </div>
                      </div>
                        <h2 class="my-4 text-primary font-weight-600">
                            اخر الاخبار
                          </h2>
                          <?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('singleCategory' , $item->id)); ?>">
                              <div class="row">
                                <div class="col-sm-12">
                                  <div class="border-bottom pb-4 pt-4">
                                    <div class="row">
                                      <div class="col-sm-8">
                                        <h5 class="font-weight-600 mb-1">
                                          <?php echo e($item->title); ?>

                                        </h5>
                                        <p class="fs-13 text-muted mb-0">
                                          <span class="mr-2">تم النشر </span><?php echo e($item->created_at->diffForHumans()); ?>

                                        </p>
                                      </div>
                                      <div class="col-sm-4">
                                        <div class="rotate-img">
                                          <img
                                            src="../image/<?php echo e($item->image); ?>"
                                            alt="banner"
                                            class="img-fluid" width="100px"
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div> 
                            </a>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                    


                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- main-panel ends -->
        <!-- container-scroller ends -->

     
        <!-- partial -->
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/category.blade.php ENDPATH**/ ?>