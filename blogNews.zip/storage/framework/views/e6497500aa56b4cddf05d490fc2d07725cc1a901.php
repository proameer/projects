
<html>
 
<body>
      <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-r-0 title-margin-right">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Hello,
                                    <span>Welcome Here</span>
                                </h1>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-4 p-l-0 title-margin-left">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item active">UI-Blank</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-12">
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Opps!</strong> Something went wrong, please check below errors.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <div class="card">
                            <div class="card-title">
                                <h4>Create Post</h4>
                                <a class="btn btn-primary float-right" href="<?php echo e(route('posts.index')); ?>">Posts</a>

                            </div>
            
          
                            <div class="card-body">
                                <div class="basic-form">
                                
                                      
                                    <?php echo Form::model($post, ['route' => ['posts.update', $post->id], 'method'=>'PATCH', 'enctype'=>'multipart/form-data']); ?>

                                    <div class="form-group">
                                        <strong>Title:</strong>
                                        <?php echo Form::text('title', null, array('placeholder' => 'Title','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>Body:</strong>
                                        <?php echo Form::textarea('body', null, array('placeholder' => 'Body','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>Image:</strong>
                                        <input type="file" name="image"  value="image/<?php echo e(old($post->image)); ?>" class="form-control">
                                        <img src="/image/<?php echo e($post->image); ?>" alt="" width="100px">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect2" for="category_id" class="form-label">  Category Name</label>
                                        <select class="form-control" name="category_id">
                                          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($item->id); ?>" class="form-control" id="category_id"name="category_id" ><?php echo e($item->nameCategory); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>                        
                                      </div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                <?php echo Form::close(); ?>

                                       
                             
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div id="extra-area-chart"></div>
                            <div id="morris-line-chart"></div>
                            <div class="footer">
                                <p>2018 © Admin Board. -
                                    <a href="#">example.com</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
 
</body>

</html>







<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/posts/edit1.blade.php ENDPATH**/ ?>