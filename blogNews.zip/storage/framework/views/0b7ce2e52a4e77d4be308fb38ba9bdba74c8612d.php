
<?php $__env->startSection('title'); ?>
    المستخدمين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  المستخدمين
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  الرئيسية
              <?php $__env->stopSection(); ?>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                       
                        <!-- /# column -->
                        <div class="col-lg-12">  
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>                                     
                             <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>">مستخدم جديد</a>
                            <?php endif; ?>

                            <div class="card">
                                
                                <div class="card-title">
                                    
                                    <h4>المستخدمين </h4>
 
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover ">
                                            <thead>
                                                <tr>
                                                    <th>الاسم</th>
                                                    <th>البريد الالكتروني</th>
                                                    <th>الدور</th>
                                                    <th>الحدث</th>
                                                </tr>
                                            </thead>
                                            <tbody>
              

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <?php if(!empty($user->getRoleNames())): ?>
                                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="badge badge-dark"><?php echo e($val); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">عرض</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">تعديل</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                                <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                                <?php echo Form::submit('حذف', ['class' => 'btn btn-danger']); ?>

                                <?php echo Form::close(); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                        <?php echo e($data->render()); ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

             
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/users/index.blade.php ENDPATH**/ ?>