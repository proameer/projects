
<html>
 
<body>
      <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-r-0 title-margin-right">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Hello,
                                    <span>Welcome Here</span>
                                </h1>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-4 p-l-0 title-margin-left">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">social media</a>
                                    </li>
                                    <li class="breadcrumb-item active">edit</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-12">
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Opps!</strong> Something went wrong, please check below errors.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <div class="card">
                            <div class="card-title">
                                <h4>Edit social media</h4>
                                <a class="btn btn-primary float-right" href="<?php echo e(route('contact.index')); ?>">back</a>

                            </div>
            
          
                            <div class="card-body">
                                <div class="basic-form">
                                
                                      
                                    <?php echo Form::model($contact, ['route' => ['contact.update', $contact->id], 'method'=>'PATCH', 'enctype'=>'multipart/form-data']); ?>

                                    <div class="form-group">
                                        <strong>Name:</strong>
                                        <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>Email:</strong>
                                        <?php echo Form::text('email', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

                                    </div>
                                    <?php echo Form::open(array('route' => 'social.store', 'method'=>'POST' , 'enctype'=>'multipart/form-data')); ?>

                                    <div class="form-group">
                                        <strong>Subject:</strong>
                                        <?php echo Form::text('subject', null, array('placeholder' => 'Subject','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>Message:</strong>
                                        <?php echo Form::text('message', null, array('placeholder' => 'Message','class' => 'form-control')); ?>

                                    </div>


                                    <button type="submit" class="btn btn-primary">Update</button>
                                <?php echo Form::close(); ?>

                                       
                             
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div id="extra-area-chart"></div>
                            <div id="morris-line-chart"></div>
                            <div class="footer">
                                <p>2018 © Admin Board. -
                                    <a href="#">example.com</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
 
</body>

</html>







<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/contact/edit.blade.php ENDPATH**/ ?>