
        <div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
            <div class="nano">
                <div class="nano-content">
                    <div class="logo"><a href="<?php echo e(url('home')); ?>"><!-- <img src="assets/images/logo.png" alt="" /> --><span>وكالة تنوير نيوز</span></a></div>
                    <ul class="mb-5">
                        <li><a class="nav-link" href="<?php echo e(route('logout')); ?>"> <i class="ti-user"></i> <?php echo e(Auth::user()->name); ?></a></li>

                        <li class="label">الرئيسية</li>
                      
                        <li><a href="<?php echo e(url('home')); ?>"><i class="ti-layout-grid2-alt"></i>لوحة التحكم </a></i></li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post-list')): ?>
                        <li><a href="<?php echo e(route('posts.index')); ?>"><i class="ti-pencil-alt"></i>المنشورات</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-list')): ?>
                        <li><a href="<?php echo e(route('categories.index')); ?>"><i class="ti-pencil-alt"></i>التصنيفات</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
                        <li><a href="<?php echo e(route('users.index')); ?>"><i class="ti-pencil-alt"></i>المستخدمين</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
                        <li><a href="<?php echo e(route('roles.index')); ?>"><i class="ti-pencil-alt"></i>الادوار</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-list')): ?>
                        <li><a href="<?php echo e(route('permissions.index')); ?>"><i class="ti-pencil-alt"></i>الصلاحيات</a></li>
                        <?php endif; ?>

                        
                        <li class="label">الاعدادات</li>
                        
                        
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('logo')): ?>
                               <li><a href="<?php echo e(route('logo.index')); ?>"><i class="ti-layout-grid2"></i> شعارات</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact')): ?>
                                <li><a href="<?php echo e(route('contact.index')); ?>"><i class="ti-email"></i>رسائل المستخدمين</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('about')): ?>
                                <li><a href="<?php echo e(route('about.index')); ?>"><i class="ti-layout-grid2"></i>حول </a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('social-media')): ?>
                                <li><a href="<?php echo e(route('social.index')); ?>"><i class="ti-layout-grid2"></i>التواصل الاجتماعي</a></li>
                            <?php endif; ?>
                        

                        



                    </ul>
                </div>
            </div>
        </div>
        <!-- /# sidebar --><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>