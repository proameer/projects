
<?php $__env->startSection('title'); ?>
    شعارات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  شعارات
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  الرئيسية
              <?php $__env->stopSection(); ?>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                      
                        <!-- /# column -->
                        <div class="col-lg-12">  
                           
                            <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <p class="text-light"><?php echo e(\Session::get('success')); ?></p>
                            </div>
                        <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-create')): ?>                                     
                             <a class="btn btn-success" href="<?php echo e(route('logo.create')); ?>">شعار جديد</a>
                            <?php endif; ?>
                            
                            <div class="card">
                               
                                <div class="card-title">
                                    
                                    <h4>شعار </h4>
 
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover ">
                                            <thead>
                                                <tr>
                                                    <th>اسم الشعار</th>
                                                    <th>الحدث</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="align-middle"><?php echo e($logo->nameClass); ?></td>
                            <td class="align-middle">
                                <a class="btn btn-info" href="<?php echo e(route('logo.show',$logo->id)); ?>">عرض</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('logo')): ?>
                                    <a class="btn btn-primary" href="<?php echo e(route('logo.edit',$logo->id)); ?>">تعديل</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('logo')): ?>
                                    <?php echo Form::open(['method' => 'DELETE','route' => ['logo.destroy', $logo->id],'style'=>'display:inline']); ?>

                                    <?php echo Form::submit('حذف', ['class' => 'btn btn-danger']); ?>

                                    <?php echo Form::close(); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php echo e($data->appends($_GET)->links()); ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                 
                </section>
            </div>
        </div>
    </div>
 
    <script src="<?php echo e(asset('assets/js/lib/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/toastr/toastr.init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/logo/index.blade.php ENDPATH**/ ?>