
<?php $__env->startSection('title'); ?>
    الصلاحيات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  الصلاحيات
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  الرئيسية
              <?php $__env->stopSection(); ?>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                       
                        <!-- /# column -->
                        <div class="col-lg-12">  
                            
                           

                            <div class="card">
                                
                                <div class="card-title">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-list')): ?>
                                    <a class="btn btn-primary float-right" href="<?php echo e(route('permissions.index')); ?>">رجوع</a>                      
                            <?php endif; ?>
                                    <h4>عرض صلاحية </h4>
 
                                </div>
                                <div class="card-body">
                                   <div class="row">
                                
                                       <div class="col-md-7">
                                        <div class="card-body">
                                            <div class="lead">
                                                <strong>اسم الصلاحية</strong><br>
                                                <?php echo e($permission->name); ?>

                                            </div>
                                        </div>
                                       
                                       </div>
                                      
                                   </div>
                                
                    
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/permissions/show.blade.php ENDPATH**/ ?>