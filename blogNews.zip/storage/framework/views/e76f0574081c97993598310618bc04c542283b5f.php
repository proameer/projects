
<?php $__env->startSection('title'); ?>
    المنشورات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="toastr">
    <div class="text-center">
        <?php if(Session::has('success')): ?>
        <?php echo e(Session::get('success')); ?>

        <?php endif; ?>
    </div>
</div>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  المنشورات
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  الرئيسية
              <?php $__env->stopSection(); ?>
                <section id="main-content">
                    <div class="row">     
                        <div class="show"></div>        
                        <!-- /# column -->
                        <div class="col-lg-12">  
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post-create')): ?>                                     
                             <a class="btn btn-success" href="<?php echo e(route('posts.create')); ?>">منشور جديد</a>
                            <?php endif; ?>

                            <div class="card">
                                
                                <div class="card-title">
                                    
                                    <h4>المنشورات </h4>
 
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover ">
                                            <thead>
                                                <tr>
                                                    <th>العنوان</th>
                                                    <th>التصنيف</th>
                                                    <th>الصورة</th>
                                                    <th>الحدث</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle">
                                <td class="align-middle">  <?php echo e(substr($post->title , 0 ,15)); ?></td>
                                <td class="align-middle"><?php echo e($post->category->nameCategory); ?></td>
                                <td class="align-middle"><img src="/image/<?php echo e($post->image); ?>" width="70px"></td>
                                
                                <td class="align-middle">
                                    <a class="btn btn-info" href="<?php echo e(route('posts.show',$post->id)); ?>">عرض</a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post-edit')): ?>
                                        <a class="btn btn-primary" href="<?php echo e(route('posts.edit',$post->id)); ?>">تعديل</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post-delete')): ?>
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['posts.destroy', $post->id],'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('حذف', ['class' => 'btn btn-danger']); ?>

                                        <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php echo e($data->appends($_GET)->links()); ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                   
                </section>
            </div>
        </div>
    </div>
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('script'); ?>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
 <script type="text/javascript">
  
      $('.show').click(function(event) {
           var form =  $(this).closest("form");
           var name = $(this).data("name");
           event.preventDefault();
           swal({
               title: `Are you sure you want to delete this record?`,
               text: "If you delete this, it will be gone forever.",
               icon: "warning",
               buttons: true,
               dangerMode: true,
           })
           .then((willDelete) => {
             if (willDelete) {
               form.submit();
             }
           });
       });
   
 </script>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/posts/index.blade.php ENDPATH**/ ?>