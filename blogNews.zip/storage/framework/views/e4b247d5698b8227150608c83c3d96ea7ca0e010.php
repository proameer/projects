
<?php $__env->startSection('title'); ?>
    رسائل المستخدمين 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  رسائل المستخدمين 
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  الرئيسية
              <?php $__env->stopSection(); ?>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                       
                        <!-- /# column -->
                        <div class="col-lg-12">  
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>خطأ!</strong>حدث <br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                            

                            <div class="card">
                                
                                <div class="card-title">
                                    
                                    <h4>رسائل المستخدمين </h4>
 
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover ">
                                            <thead>
                                                <tr>
                                                    <th>اسم المستخدم</th>
                                                    <th>البريد الالكتروني </th>
                                                    <th>الموضوع </th>
                                                    <th>الرسالة </th>
                                                    <th>الحدث</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle">
                                <td class="align-middle">  <?php echo e(substr($post->name , 0 ,15)); ?></td>
                                <td class="align-middle">  <?php echo e(substr($post->email , 0 ,50)); ?></td>
                                <td class="align-middle">  <?php echo e(substr($post->subject , 0 ,50)); ?></td>
                                <td class="align-middle">  <?php echo e(substr($post->message , 0 ,50)); ?></td>
                                <td class="align-middle">
                                    <a class="btn btn-info" href="<?php echo e(route('contact.show',$post->id)); ?>">عرض</a>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post-delete')): ?>
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['contact.destroy', $post->id],'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('حذف', ['class' => 'btn btn-danger']); ?>

                                        <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php echo e($data->appends($_GET)->links()); ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

              
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/contact/index.blade.php ENDPATH**/ ?>