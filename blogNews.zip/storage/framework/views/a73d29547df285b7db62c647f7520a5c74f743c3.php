
<?php $__env->startSection('title'); ?>
    التواصل الاجتماعي
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  التواصل الاجتماعي
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  عرض
              <?php $__env->stopSection(); ?>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                       
                        <!-- /# column -->
                        <div class="col-lg-12">  
                            
                           

                            <div class="card">
                                
                                <div class="card-title">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post-list')): ?>
                                    <a class="btn btn-primary float-right" href="<?php echo e(route('social.index')); ?>">رجوع</a>                      
                            <?php endif; ?>
                                    <h4>عرض </h4>
 
                                </div>
                                <div class="card-body">
                                   <div class="row">
                               
                                       <div class="col-md-7">

                                        <div class="lead">
                                            <strong>الرابط</strong><br>
                                            <?php echo e($post->link); ?>

                                        </div><hr>
                                        <div class="lead">
                                            <strong>اسم الشعار</strong><br>
                                            <?php echo e($post->logo->nameClass); ?>

                                        </div><hr>
          
                                       
                                       </div>
                                      
                                   </div>
                                
                    
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/social/show.blade.php ENDPATH**/ ?>