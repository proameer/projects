
<?php $__env->startSection('title'); ?>
    المستخدمين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
              <?php $__env->startSection('title-header'); ?>
                  المستخدمين
              <?php $__env->stopSection(); ?>
              <?php $__env->startSection('subTitle-header'); ?>
                  اضافة
              <?php $__env->stopSection(); ?>
                    <!-- /# column -->
                    <div class="col-lg-12">
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>خطأ!</strong>حدث <br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <div class="card">
                            <div class="card-title">
                                <h4>انشاء مستخدم</h4>
                                <a class="btn btn-primary float-right" href="<?php echo e(route('users.index')); ?>">رجوع</a>

                            </div>
            
          
                            <div class="card-body">
                                <div class="basic-form">
                                    <?php echo Form::open(array('route' => 'users.store','method'=>'POST')); ?>

                                    <div class="form-group">
                                        <strong>الاسم:</strong>
                                        <?php echo Form::text('name', null, array('placeholder' => 'الاسم','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>البريد الالكتروني:</strong>
                                        <?php echo Form::text('email', null, array('placeholder' => 'البريد الالكتروني','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>كلمة المرور:</strong>
                                        <?php echo Form::password('password', array('placeholder' => 'كلمة المرور','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>اعادة كلمة المرور:</strong>
                                        <?php echo Form::password('password_confirmation', array('placeholder' => 'اعادة كلمة المرور','class' => 'form-control')); ?>

                                    </div>
                                    <div class="form-group">
                                        <strong>الدور:</strong>
                                        <?php echo Form::select('roles[]', $roles,[], array('class' => 'form-control','multiple')); ?>

                                    </div>
                                    <button type="submit" class="btn btn-primary">اضافة</button>
                                <?php echo Form::close(); ?>

                             
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div id="extra-area-chart"></div>
                            <div id="morris-line-chart"></div>
                            <div class="footer">
                                <p>2018 © Admin Board. -
                                    <a href="#">example.com</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogNews\resources\views/users/create.blade.php ENDPATH**/ ?>