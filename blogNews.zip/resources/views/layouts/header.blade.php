
    <div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="float-left">
                        <div class="hamburger sidebar-toggle">
                            <span class="line"></span>
                            <span class="line"></span>
                            <span class="line"></span>
                        </div>
                    </div>
                    <div class="float-right">
                        <li><a class="nav-link text-dark" href="{{ route('logout') }}">  تسجيل خروج <i class="ti-power-off text-dark"></i> </a></li>

                       
                    </div>
                </div>
            </div>
        </div>
    </div>

