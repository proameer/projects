<link
rel="stylesheet"
href="{{asset('assetsuser/vendors/mdi/css/materialdesignicons.min.css')}}"
/>
<link rel="stylesheet" href="{{asset('assetsuser/vendors/aos/dist/aos.css/aos.css')}}" />
<!-- End plugin css for this page -->
<link rel="shortcut icon" href="{{asset('assetsuser/images/favicon.png')}}" />
<!-- inject:css -->
<link rel="stylesheet" href="{{asset('assetsuser/css/style.css')}}">
<!-- endinject -->
<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.7/css/all.css">
