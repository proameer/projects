<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Categories;
use App\Models\About;
use App\Models\Contact;

function footer(){
    echo "hello";
};